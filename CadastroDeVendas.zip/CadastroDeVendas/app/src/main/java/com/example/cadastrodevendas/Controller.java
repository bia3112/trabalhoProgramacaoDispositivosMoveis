package com.example.cadastrodevendas;

import java.util.ArrayList;
import com.example.cadastrodevendas.modelo.Cliente;
import com.example.cadastrodevendas.modelo.ItemVenda;
import com.example.cadastrodevendas.modelo.Pedido;

public class Controller {

    private static Controller instancia;
    private ArrayList<Cliente> listaCliente;
    private ArrayList<ItemVenda> listaItemVenda;
    private ArrayList<Pedido> listaItemVendaPedido;
    private ArrayList<Pedido> salvarListaItem;
    private ArrayList<Pedido> listaParcelas;
    private ArrayList<Pedido> listaPedido;

    public static Controller getInstance() {
        if(instancia == null){
            return instancia = new Controller();
        }else{
            return instancia;
        }
    }

    private Controller(){
        listaCliente = new ArrayList<>();
        listaItemVenda = new ArrayList<>();
        listaItemVendaPedido = new ArrayList<>();
        salvarListaItem = new ArrayList<>();
        listaParcelas = new ArrayList<>();
        listaPedido = new ArrayList<>();
    }

    public void salvarCliente(Cliente cliente){
        listaCliente.add(cliente);
    }
    public ArrayList<Cliente> retornarCliente(){
        return listaCliente;
    }

    public void salvarItemVenda(ItemVenda itemVenda){
        listaItemVenda.add(itemVenda);
    }
    public ArrayList<ItemVenda> retornarItemVenda(){
        return listaItemVenda;
    }

    public void salvarListaItem(Pedido pedido) {
        salvarListaItem.add(pedido);
    }

    public ArrayList<Pedido> retornarListaItemPedido(){
        return listaItemVendaPedido;
    }

    public ArrayList<Pedido> retornarParcelas(){
        return listaParcelas;
    }

    public void salvarPedido(Pedido pedido){
        listaPedido.add(pedido);
    }

}
