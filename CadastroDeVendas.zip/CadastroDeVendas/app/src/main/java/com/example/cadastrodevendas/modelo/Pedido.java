package com.example.cadastrodevendas.modelo;

import java.util.ArrayList;

public class Pedido {

private int qtdItem;
private ArrayList<Cliente> clientes;
private ArrayList<ItemVenda> itemPedido;
private int qtdParcela;

    public Pedido() {
    }

    public Pedido(int qtdItem, ArrayList<Cliente> clientes, ArrayList<ItemVenda> itemPedido, int qtdParcela) {
        this.qtdItem = qtdItem;
        this.clientes = clientes;
        this.itemPedido = itemPedido;
        this.qtdParcela = qtdParcela;
    }

    public int getQtdItem() {
        return qtdItem;
    }

    public void setQtdItem(int qtdItem) {
        this.qtdItem = qtdItem;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public ArrayList<ItemVenda> getItemPedido() {
        return itemPedido;
    }

    public void setItemPedido(ArrayList<ItemVenda> itemPedido) {
        this.itemPedido = itemPedido;
    }

    public int getQtdParcela() {
        return qtdParcela;
    }

    public void setQtdParcela(int qtdParcela) {
        this.qtdParcela = qtdParcela;
    }
}
