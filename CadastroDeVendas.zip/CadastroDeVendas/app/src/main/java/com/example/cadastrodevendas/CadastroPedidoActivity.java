package com.example.cadastrodevendas;

import androidx.appcompat.app.AppCompatActivity;


import android.content.ClipData;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cadastrodevendas.modelo.Cliente;
import com.example.cadastrodevendas.modelo.ItemVenda;
import com.example.cadastrodevendas.modelo.Pedido;

import java.util.ArrayList;

public class CadastroPedidoActivity extends AppCompatActivity {

    private Spinner spCliente;
    private Spinner spItemVenda;
    private int posicaoSelecionada = 0;
    private ArrayList<Cliente> listaCliente;
    private ArrayList<ItemVenda> listaItemVenda;
    private ArrayList<Pedido> listaParcelas;
    private TextView tvValorUnitario;
    private EditText edQtdItemVenda;
    private Button btAddItem;
    private TextView tvListaItem;
    private TextView tvValorTotalItem;
    private TextView tvQtdItem;
    private TextView tvErrorCliente;
    private TextView tvErrorItem;
    private RadioGroup rgSistema;
    private RadioButton rbAvista;
    private RadioButton rbAprazo;
    private LinearLayout lyParcelas;
    private EditText edQtdParcelas;
    private Spinner spValorParcelas;
    private Button btPagar;
    private TextView tvValorTotalPedido;
    private Button btConfirmar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pedido);

        spCliente = findViewById(R.id.spCliente);
        spItemVenda = findViewById(R.id.spItemVenda);

        tvValorUnitario = findViewById(R.id.tvValorUnitario);
        edQtdItemVenda = findViewById(R.id.edQtdItemVenda);

        btAddItem = findViewById(R.id.btAddItem);
        tvListaItem = findViewById(R.id.tvListaItem);
        tvValorTotalItem = findViewById(R.id.tvValorTotalItem);
        tvQtdItem = findViewById(R.id.tvQtdItem);

        tvErrorItem = findViewById(R.id.tvErrorItem);
        tvErrorCliente = findViewById(R.id.tvErrorCliente);

        rgSistema = findViewById(R.id.rgSistema);
        rbAprazo = findViewById(R.id.rbAprazo);
        rbAvista = findViewById(R.id.rbAvista);

        lyParcelas = findViewById(R.id.lyParcelas);
        edQtdParcelas = findViewById(R.id.edQtdParcelas);
        spValorParcelas = findViewById(R.id.spValorParcelas);
        btPagar = findViewById(R.id.btPagar);

        tvValorTotalPedido = findViewById(R.id.tvValorTotalPedido);

        //spinner Cliente
        spCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionada = posicao;
                    tvErrorCliente.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //spinner Item
        spItemVenda.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionada = posicao -1;
                    tvErrorItem.setVisibility(View.GONE);

                    ItemVenda itemSelecionado = listaItemVenda.get(posicao - 1);
                    double valorItem = itemSelecionado.getValorUn();
                    // Exibe o valor do item na TextView
                    tvValorUnitario.setText("R$" + valorItem);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionarItem();
            }
        });

        carregarCliente();
        carregarItemVenda();
        exibirListaPedido();

        calcularValorTotal();

        rgSistema.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i == rbAprazo.getId()){
                    lyParcelas.setVisibility(View.VISIBLE);
                    calcularParcelas();
                }else{
                    lyParcelas.setVisibility(View.GONE);
                }
            }
        });

        btPagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exibirValorPagamento();
            }
        });

        calcularValorTotalPedido();

        btConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confimarPedido();
            }
        });

    }

    //adicionar item na lista do pedido
    public void adicionarItem() {
        int qtdItem;

        if(edQtdItemVenda.getText().toString().isEmpty()){
            edQtdItemVenda.setError("A quantidade precisa ser informada!");
            edQtdItemVenda.requestFocus();
            return;
        }else{
            qtdItem = Integer.parseInt(edQtdItemVenda.getText().toString());
            if(qtdItem <= 0){
                edQtdItemVenda.setError("Quantidade precisa ser maior que 0!");
                edQtdItemVenda.requestFocus();
                return;
            }
        }

        if(posicaoSelecionada < 0 || posicaoSelecionada >= listaItemVenda.size()){
            tvErrorItem.setVisibility(View.VISIBLE);
            return;
        }

        ArrayList<ItemVenda> listaItens = new ArrayList<>();
        ItemVenda itens = listaItemVenda.get(posicaoSelecionada);
        listaItens.add(itens);
        Pedido pedido = new Pedido();
        pedido.setQtdItem(qtdItem);
        pedido.setItemPedido(listaItens);

        Controller.getInstance().salvarListaItem(pedido);
        Toast.makeText(this, "Item salvo com sucesso!", Toast.LENGTH_LONG).show();

    }

    //Mostrar as opções no spinner Item
    public void carregarItemVenda() {
        listaItemVenda = Controller.getInstance().retornarItemVenda();
        String[]vetItemVenda = new String[listaItemVenda.size() + 1];
        vetItemVenda[0] = "Selecione o item";

        for(int i=0; i < listaItemVenda.size(); i++){
            ItemVenda itemVenda = listaItemVenda.get(i);
            vetItemVenda[i+1] = itemVenda.getCodigo() + " - " + itemVenda.getDescricao();
        }
        ArrayAdapter adapter = new ArrayAdapter(CadastroPedidoActivity.this,
                android.R.layout.simple_dropdown_item_1line, vetItemVenda);

        spItemVenda.setAdapter(adapter);
    }

    //Mostrar as opções no spinner Cliente
    public void carregarCliente() {
        listaCliente = Controller.getInstance().retornarCliente();
        String[]vetCliente = new String[listaCliente.size() + 1];
        vetCliente[0] = "Selecione o cliente";

        for(int i = 0; i < listaCliente.size(); i++){
            Cliente cliente = listaCliente.get(i);
            vetCliente[i+1] = cliente.getNome() + " - " + cliente.getCpf();
        }
        ArrayAdapter adapter = new ArrayAdapter(CadastroPedidoActivity.this,
                android.R.layout.simple_dropdown_item_1line, vetCliente);

        spCliente.setAdapter(adapter);
    }

    //exibir lista de itens
    public void exibirListaPedido() {
        ArrayList<Pedido> lista = Controller.getInstance().retornarListaItemPedido();
        String texto = "";
        int qtdItens = 0;


        for(Pedido pedido : lista){
            for(ItemVenda item : pedido.getItemPedido()){
                texto += item.getCodigo() + " - " + item.getDescricao() +
                        " - R$" + item.getValorUn() +
                        " - Qtd:" + pedido.getQtdItem() +
                        "\n---------------------------------------\n";
                qtdItens += pedido.getQtdItem();
            }
        }
        tvListaItem.setText(texto);
        tvQtdItem.setText(String.valueOf(qtdItens));
    }

    private double total;

    //calculo valor total dos itens
    public void calcularValorTotal() {
        ArrayList<Pedido> lista = Controller.getInstance().retornarListaItemPedido();
         total = 0.0;

        for(Pedido pedido : lista){
            for(ItemVenda item : pedido.getItemPedido()){
                total += item.getValorUn() * pedido.getQtdItem();
            }
        }
        tvValorTotalItem.setText(String.valueOf("R$" + total));
    }
    private double totalPedido;

    //calculo valor total do pedido
    public void calcularValorTotalPedido(){
        ArrayList<Pedido> lista = Controller.getInstance().retornarListaItemPedido();
        totalPedido = 0.0;

        if(rbAprazo.isChecked()){
            double acrescentar = total * 0.05;
            totalPedido = total + acrescentar;
        }else{
            double descontar = total/0.05;
            totalPedido = total - descontar;
        }

        tvValorTotalPedido.setText(String.valueOf("R$" + totalPedido));
    }

    //calculo valores das parcelas
    public void calcularParcelas() {
        listaParcelas = Controller.getInstance().retornarParcelas();
        double valorTotal = totalPedido;
        String[]vetParcelas = new String[listaParcelas.size() + 1];
        vetParcelas[0] = "Valor das Parcelas";

        for(int i =0; i < listaParcelas.size(); i++){
            Pedido pedido = listaParcelas.get(i);
            double parcela = valorTotal/pedido.getQtdParcela();
            vetParcelas[i+1] = String.format("R$", parcela);
        }

        ArrayAdapter adapter = new ArrayAdapter(CadastroPedidoActivity.this,
                android.R.layout.simple_dropdown_item_1line, vetParcelas);

    }

    private void exibirValorPagamento() {
        int qtdParcelas;

        if(edQtdParcelas.getText().toString().isEmpty()){
            edQtdParcelas.setError("A quantidade precisa ser informada!");
            edQtdParcelas.requestFocus();
            return;
        }else{
            qtdParcelas = Integer.parseInt(edQtdParcelas.getText().toString());
            if(qtdParcelas <= 0){
                edQtdParcelas.setError("A quantidade precisa ser maior que z");
                edQtdParcelas.requestFocus();
                return;
            }
        }

        Pedido pedido = new Pedido();
        pedido.setQtdParcela(qtdParcelas);

        Controller.getInstance().salvarListaItem(pedido);
    }

    private void confimarPedido() {
        Pedido pedido = new Pedido();
        Controller.getInstance().salvarPedido(pedido);
        Toast.makeText(this, "Pedido confirmado com sucesso!", Toast.LENGTH_LONG).show();
    }

}