package com.example.cadastrodevendas.modelo;

public class ItemVenda {

    private int codigo;
    private String descricao;
    private double valorUn;

    public ItemVenda() {
    }

    public ItemVenda(int codigo, String descricao, double valorUn) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.valorUn = valorUn;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValorUn() {
        return valorUn;
    }

    public void setValorUn(double valorUn) {
        this.valorUn = valorUn;
    }
}
