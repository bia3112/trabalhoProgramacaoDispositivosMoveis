package com.example.cadastrodevendas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cadastrodevendas.modelo.ItemVenda;

public class CadastroItemVendaActivity extends AppCompatActivity {

    private EditText edCodigo;
    private EditText edDescricao;
    private EditText edValorUn;
    private Button btAdicionar;
    private TextView tvItemVendaCadastro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_item_venda);

        edCodigo = findViewById(R.id.edCodigo);
        edDescricao = findViewById(R.id.edDescricao);
        edValorUn = findViewById(R.id.edValorUn);
        btAdicionar = findViewById(R.id.btAdicionar);
        tvItemVendaCadastro = findViewById(R.id.tvItemVendaCadastro);

        atualizarItemVenda();

        btAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                salvarItemVenda();
            }
        });
    }

    private void atualizarItemVenda() {
        String texto = "";
        for(ItemVenda itemVenda : Controller.getInstance().retornarItemVenda()){
            texto += "Código:" + itemVenda.getCodigo() +
                    " - Descrição:" + itemVenda.getDescricao() +
                    " - Valor Unitário:R$" + itemVenda.getValorUn() +
                    "\n---------------------------------------\n";
        }
        tvItemVendaCadastro.setText(texto);
    }

    private void salvarItemVenda() {
        if(edCodigo.getText().toString().isEmpty()){
            edCodigo.setError("Informe o código do item!");
            return;
        }
        if(edDescricao.getText().toString().isEmpty()){
            edDescricao.setError("Informe a descrição do item!");
            return;
        }
        if(edValorUn.getText().toString().isEmpty()){
            edValorUn.setError("Informe o valor unitário do item!");
            return;
        }

        ItemVenda itemVenda = new ItemVenda();
        itemVenda.setCodigo(Integer.parseInt(edCodigo.getText().toString()));
        itemVenda.setDescricao(edDescricao.getText().toString());
        itemVenda.setValorUn(Double.parseDouble(edValorUn.getText().toString()));

        Controller.getInstance().salvarItemVenda(itemVenda);
        Toast.makeText(CadastroItemVendaActivity.this,
                "Item venda cadastrado com sucesso!",
                Toast.LENGTH_LONG).show();

        this.finish();
    }


}